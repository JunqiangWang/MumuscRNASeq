

#' This function do Stouffer integration of the PA in each cluster by rows
#' @param  seu The seurat object
#'@cluster.by The colname of the meta used as clustering info
#'@return Integreated NES
#' @export
StoufferIntegrateSeuClusterRows<-function(seu,
                                          assay=c("Activity", "RNA"),
                                          slot=c("data", "scale.data", "counts"),
                                          cluster.by="seurat_clusters"){


  require(Seurat)


  Idents(seu) <- cluster.by


  if(cluster.by=="seurat_clusters"){

    clusters<-paste0("C", seu@meta.data$seurat_clusters)

    seu@meta.data$tmp<-clusters

    Idents(seu) <- "tmp"

    cluster.by<-"tmp"

  }



  tmp<-match(cluster.by, colnames(seu@meta.data))

  clusters<-unique(seu@meta.data[,tmp])

  clusters<-sort(as.vector(clusters))



   nes.stouffer<-vector()


for (i in clusters){

  seu.i <- subset(seu, idents =i)


   mat<-GetAssayData(object = seu.i[[assay]], slot = slot) %>% as.matrix()

  #mat<-as.matrix(seu.i@assays$Activity@data)

  nes.stouffer.i<-rowSums(mat)/sqrt(ncol(mat))

  nes.stouffer<-cbind(nes.stouffer, nes.stouffer.i)

}

   nes.stouffer<-as.matrix(nes.stouffer)

rownames(nes.stouffer)<-rownames(seu)
colnames(nes.stouffer)<-clusters

return(nes.stouffer)

}



